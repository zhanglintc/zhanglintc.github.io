Mac下安装方法
==========

## 安装：
运行install.py

    pytyon install.py

完成后使用命令可以即刻生效

    source .bash_profile

如果不实用上述命令也可以关闭Shell（Terminal）后重新打开

## 卸载：
运行uninstall.py

    pytyon install.py

## 补充：
wb.py 文件夹路径更改后重新运行install.py即可