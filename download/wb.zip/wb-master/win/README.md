Windows下安装方法
==========

## 安装：
运行install.py

## 卸载：
运行uninstall.py

## 补充：
wb.py 文件夹路径更改后重新运行install.py即可